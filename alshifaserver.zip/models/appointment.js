const mongoose = require("mongoose");
const UserAppointment = new mongoose.Schema({
    firstName: {
        type: String
    },
    lastName: {
        type: String
    },
    email: {
        type: String
    },
 
    phone: {
        type: String
    },
    appointment: {
        type: String
    },
    selectedDate: {
        type: String
    },
    // isApointment:{
    //     type:String
    // },
       
  
  

  
    
})

module.exports = mongoose.model("APPOINTMENTS", UserAppointment);