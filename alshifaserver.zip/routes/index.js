const data = require("./data");
const mailchimpdata =require("./mailchimpconfiguration")

module.exports = {
    data,
    mailchimpdata
}